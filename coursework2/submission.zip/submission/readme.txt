use "main_file.py" to generate results for parts 1 to 4, which use funcitons implemented in "poission.py". Results for part 1 and 2
are written to a file "results.txt".